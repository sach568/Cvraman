import axios from 'axios';

const api = axios.create({
  baseURL: '/api',
  withCredentials: true,
  headers: { 'Content-Type': 'multipart/form-data' }
});

export const login = (email, password) => api.post('/login.php', { email, password });
export const register = (data) => api.post('/register.php', data);
export const logout = () => api.post('/logout.php');
export const getUser = () => api.get('/getUser.php');
export const getProjects = (search = '') => api.get(`/projects.php?search=${search}`);
export const getProject = (id) => api.get(`/project.php?id=${id}`);
export const createProject = (formData) => api.post('/projects.php', formData);
export const updateProject = (id, data) => api.put(`/project.php?id=${id}`, data);
export const deleteProject = (id) => api.delete(`/project.php?id=${id}`);
export const submitProject = (id) => api.post('/submit_project.php', { id });
export const getSubjects = () => api.get('/subjects.php');
export const addSubject = (name) => api.post('/subjects.php', { name });
export const deleteSubject = (id) => api.delete('/subjects.php', { data: { id } });
export const getUsers = () => api.get('/users.php');
export const createUser = (type, data) => api.post('/users.php', { type, ...data });
export const getComments = (projectId) => api.get(`/comments.php?project_id=${projectId}`);
export const addComment = (projectId, comment) => api.post('/comments.php', { project_id: projectId, comment });

export default api;