import { Outlet, Link, useNavigate } from "react-router-dom";
import { logout } from "../api";

export default function Layout({ user, setUser }) {
  const navigate = useNavigate();
  const handleLogout = async () => {
    await logout();
    setUser(null);
    navigate("/login");
  };

  return (
    <>
      {/* Top Navbar */}
      <nav
        className="navbar navbar-dark bg-gradient sticky-top"
        style={{
          background: "linear-gradient(135deg, #1e3c72, #2a5298)",
          boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
        }}
      >
        <div className="container-fluid">
          <button
            className="btn btn-light d-md-none"
            type="button"
            data-bs-toggle="offcanvas"
            data-bs-target="#sidebarMobile"
          >
            <i className="fas fa-bars"></i>
          </button>
          <Link className="navbar-brand mx-auto" to="/">
            <img
              src="https://via.placeholder.com/120x40?text=CVR+UNI"
              alt="Logo"
              height="35"
              className="d-inline-block align-top me-2"
            />
            <span className="fw-bold">Dr. C.V. Raman University</span>
          </Link>
          <div className="dropdown">
            <button
              className="btn btn-outline-light dropdown-toggle"
              data-bs-toggle="dropdown"
            >
              <i className="fas fa-user-circle"></i> {user?.name}
            </button>
            <ul className="dropdown-menu dropdown-menu-end">
              <li>
                <button className="dropdown-item" onClick={handleLogout}>
                  <i className="fas fa-sign-out-alt me-2"></i>Logout
                </button>
              </li>
            </ul>
          </div>
        </div>
      </nav>

      {/* Mobile Sidebar Offcanvas */}
      <div
        className="offcanvas offcanvas-start"
        tabIndex="-1"
        id="sidebarMobile"
      >
        <div className="offcanvas-header bg-dark text-white">
          <h5>Menu</h5>
          <button
            type="button"
            className="btn-close btn-close-white"
            data-bs-dismiss="offcanvas"
          ></button>
        </div>
        <div className="offcanvas-body">
          {renderSidebar(user, handleLogout)}
        </div>
      </div>

      {/* Desktop Sidebar */}
      <div className="d-flex">
        <div
          className="d-none d-md-block bg-dark text-white vh-100 p-3"
          style={{
            width: "280px",
            position: "fixed",
            top: "56px",
            left: 0,
            overflowY: "auto",
            boxShadow: "2px 0 10px rgba(0,0,0,0.1)",
          }}
        >
          <div className="text-center mb-4 pb-2 border-bottom border-secondary">
            <img
              src="https://via.placeholder.com/100x40?text=CVR"
              alt="Logo"
              className="mb-2"
            />
            <h6>CVR Project Hub</h6>
          </div>
          {renderSidebar(user, handleLogout)}
        </div>
        <main
          className="flex-grow-1 bg-light"
          style={{
            marginLeft: "280px",
            padding: "20px",
            marginTop: "56px",
            minHeight: "calc(100vh - 56px)",
          }}
        >
          <Outlet />
        </main>
      </div>

      {/* Footer (visible on all pages) */}
      <footer
        style={{ marginLeft: "280px" }}
        className="bg-dark text-white-50 py-4"
      >
        <div className="container">
          <div className="row">
            <div className="col-md-4 text-center text-md-start mb-3 mb-md-0">
              <h6>
                <i className="fas fa-building me-2"></i>Nishi And Co Group
              </h6>
              <p className="small">
                123, Tech Park, Near University Campus, Vaishali, Bihar
                <br />
                <i className="fas fa-phone me-1"></i> +91-98765 43210
                <br />
                <i className="fas fa-envelope me-1"></i> nishi@co.group
              </p>
            </div>
            <div className="col-md-4 text-center mb-3 mb-md-0">
              <h6>Follow Us</h6>
              <div className="d-flex justify-content-center gap-3">
                <a href="#" className="text-white-50" target="_blank">
                  <i className="fab fa-github fa-lg"></i>
                </a>
                <a href="#" className="text-white-50" target="_blank">
                  <i className="fab fa-facebook fa-lg"></i>
                </a>
                <a href="#" className="text-white-50" target="_blank">
                  <i className="fab fa-twitter fa-lg"></i>
                </a>
                <a href="#" className="text-white-50" target="_blank">
                  <i className="fab fa-instagram fa-lg"></i>
                </a>
              </div>
            </div>
            <div className="col-md-4 text-center text-md-end">
              <small>
                © {new Date().getFullYear()} Dr. C.V. Raman University
              </small>
              <br />
              <small>
                Developed with <i className="fas fa-heart text-danger"></i> by
                Nishi And Co
              </small>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}

function renderSidebar(user, logout) {
  return (
    <ul className="nav flex-column">
      <li className="nav-item mb-2">
        <Link className="nav-link text-white py-2 rounded" to="/dashboard">
          <i className="fas fa-tachometer-alt me-3"></i> Dashboard
        </Link>
      </li>
      {user?.role === "student" && (
        <>
          <li className="nav-item mb-2">
            <Link className="nav-link text-white py-2 rounded" to="/projects">
              <i className="fas fa-folder-open me-3"></i> My Projects
            </Link>
          </li>
          <li className="nav-item mb-2">
            <Link
              className="nav-link text-white py-2 rounded"
              to="/projects/create"
            >
              <i className="fas fa-plus-circle me-3"></i> New Project
            </Link>
          </li>
        </>
      )}
      {user?.role === "mentor" && (
        <li className="nav-item mb-2">
          <Link className="nav-link text-white py-2 rounded" to="/projects">
            <i className="fas fa-tasks me-3"></i> Assigned Projects
          </Link>
        </li>
      )}
      {user?.role === "admin" && (
        <>
          <li className="nav-item mb-2">
            <Link
              className="nav-link text-white py-2 rounded"
              to="/admin/subjects"
            >
              <i className="fas fa-book me-3"></i> Subjects
            </Link>
          </li>
          <li className="nav-item mb-2">
            <Link
              className="nav-link text-white py-2 rounded"
              to="/admin/users"
            >
              <i className="fas fa-users me-3"></i> Users
            </Link>
          </li>
        </>
      )}
      <li className="nav-item mt-3">
        <button className="btn btn-outline-danger w-100" onClick={logout}>
          <i className="fas fa-sign-out-alt me-2"></i> Logout
        </button>
      </li>
    </ul>
  );
}
