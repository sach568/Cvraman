import { BrowserRouter, Routes, Route, Navigate } from "react-router-dom";
import { useEffect, useState } from "react";
import { getUser } from "./api";
import Login from "./pages/Login";
import Register from "./pages/Register";
import StudentDashboard from "./pages/StudentDashboard";
import StudentProjects from "./pages/StudentProjects";
import CreateProject from "./pages/CreateProject";
import EditProject from "./pages/EditProject";
import MentorDashboard from "./pages/MentorDashboard";
import MentorProjects from "./pages/MentorProjects";
import MentorProjectReview from "./pages/MentorProjectReview";
import AdminDashboard from "./pages/AdminDashboard";
import AdminSubjects from "./pages/AdminSubjects";
import AdminUsers from "./pages/AdminUsers";
import Layout from "./components/Layout";

function App() {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    getUser()
      .then((res) => {
        if (res.data.authenticated) setUser(res.data.user);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  if (loading)
    return (
      <div className="text-center mt-5">
        <div className="spinner-border text-primary"></div>
        <p>Loading...</p>
      </div>
    );

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/login" element={<Login setUser={setUser} />} />
        <Route path="/register" element={<Register setUser={setUser} />} />
        <Route element={<Layout user={user} setUser={setUser} />}>
          <Route path="/" element={<Navigate to="/dashboard" />} />
          <Route
            path="/dashboard"
            element={
              user?.role === "student" ? (
                <StudentDashboard />
              ) : user?.role === "mentor" ? (
                <MentorDashboard />
              ) : user?.role === "admin" ? (
                <AdminDashboard />
              ) : (
                <Navigate to="/login" />
              )
            }
          />
          <Route
            path="/projects"
            element={
              user?.role === "student" ? (
                <StudentProjects />
              ) : user?.role === "mentor" ? (
                <MentorProjects />
              ) : (
                <Navigate to="/" />
              )
            }
          />
          <Route
            path="/projects/create"
            element={
              user?.role === "student" ? <CreateProject /> : <Navigate to="/" />
            }
          />
          <Route
            path="/projects/edit/:id"
            element={
              user?.role === "student" ? <EditProject /> : <Navigate to="/" />
            }
          />
          <Route
            path="/projects/review/:id"
            element={
              user?.role === "mentor" ? (
                <MentorProjectReview />
              ) : (
                <Navigate to="/" />
              )
            }
          />
          <Route
            path="/admin/subjects"
            element={
              user?.role === "admin" ? <AdminSubjects /> : <Navigate to="/" />
            }
          />
          <Route
            path="/admin/users"
            element={
              user?.role === "admin" ? <AdminUsers /> : <Navigate to="/" />
            }
          />
        </Route>
      </Routes>
    </BrowserRouter>
  );
}

export default App;
