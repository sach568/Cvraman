import { useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import { getProject, updateProject, getComments, addComment } from "../api";

export default function MentorProjectReview() {
  const { id } = useParams();
  const [project, setProject] = useState(null);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState("");
  const [status, setStatus] = useState("");
  const [feedback, setFeedback] = useState("");

  useEffect(() => {
    loadData();
  }, [id]);
  const loadData = async () => {
    const p = await getProject(id);
    setProject(p.data);
    setStatus(p.data.status);
    setFeedback(p.data.feedback || "");
    const c = await getComments(id);
    setComments(c.data);
  };
  const handleStatusUpdate = async () => {
    await updateProject(id, { status, feedback });
    loadData();
  };
  const handleAddComment = async () => {
    await addComment(id, newComment);
    setNewComment("");
    loadData();
  };
  if (!project) return <div>Loading...</div>;
  return (
    <div className="card">
      <div className="card-header">Review Project: {project.title}</div>
      <div className="card-body">
        <p>
          <strong>Student:</strong> {project.student_name} (
          {project.roll_number})
        </p>
        <p>
          <strong>Subject:</strong> {project.subject_name}
        </p>
        <p>
          <strong>Branch:</strong> {project.branch}
        </p>
        <p>
          <strong>Description:</strong>
          <br />
          {project.description}
        </p>
        <p>
          <strong>File:</strong>{" "}
          {project.file_path && (
            <a
              href={`http://localhost/project-api/uploads/${project.file_path}`}
              target="_blank"
            >
              Download
            </a>
          )}
        </p>
        <hr />
        <div className="mb-3">
          <label>Status</label>
          <select
            className="form-select"
            value={status}
            onChange={(e) => setStatus(e.target.value)}
          >
            <option value="under_review">Under Review</option>
            <option value="approved">Approved</option>
            <option value="revisions_needed">Revisions Needed</option>
          </select>
        </div>
        <div className="mb-3">
          <label>Feedback</label>
          <textarea
            className="form-control"
            rows="3"
            value={feedback}
            onChange={(e) => setFeedback(e.target.value)}
          />
        </div>
        <button className="btn btn-primary mb-3" onClick={handleStatusUpdate}>
          Update Status
        </button>
        <hr />
        <h5>Discussion</h5>
        {comments.map((c) => (
          <div key={c.id} className="border p-2 mb-2">
            <strong>{c.name}</strong> <small>{c.created_at}</small>
            <p>{c.comment}</p>
          </div>
        ))}
        <textarea
          className="form-control mb-2"
          rows="2"
          placeholder="Add a comment..."
          value={newComment}
          onChange={(e) => setNewComment(e.target.value)}
        />
        <button className="btn btn-secondary" onClick={handleAddComment}>
          Post Comment
        </button>
      </div>
    </div>
  );
}
