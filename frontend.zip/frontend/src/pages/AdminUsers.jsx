import { useState, useEffect } from "react";
import { getUsers, createUser } from "../api";

export default function AdminUsers() {
  const [users, setUsers] = useState({ students: [], mentors: [] });
  const [studentForm, setStudentForm] = useState({
    name: "",
    email: "",
    roll_number: "",
    branch: "CSE",
  });
  const [mentorForm, setMentorForm] = useState({ name: "", email: "" });
  useEffect(() => {
    load();
  }, []);
  const load = async () => {
    const res = await getUsers();
    setUsers(res.data);
  };
  const addStudent = async () => {
    await createUser("student", studentForm);
    setStudentForm({ name: "", email: "", roll_number: "", branch: "CSE" });
    load();
  };
  const addMentor = async () => {
    await createUser("mentor", mentorForm);
    setMentorForm({ name: "", email: "" });
    load();
  };
  return (
    <div>
      <div className="row">
        <div className="col-md-6">
          <div className="card">
            <div className="card-header">Add Student</div>
            <div className="card-body">
              <input
                placeholder="Name"
                className="form-control mb-2"
                value={studentForm.name}
                onChange={(e) =>
                  setStudentForm({ ...studentForm, name: e.target.value })
                }
              />
              <input
                placeholder="Email"
                className="form-control mb-2"
                value={studentForm.email}
                onChange={(e) =>
                  setStudentForm({ ...studentForm, email: e.target.value })
                }
              />
              <input
                placeholder="Roll Number"
                className="form-control mb-2"
                value={studentForm.roll_number}
                onChange={(e) =>
                  setStudentForm({
                    ...studentForm,
                    roll_number: e.target.value,
                  })
                }
              />
              <select
                className="form-select mb-2"
                value={studentForm.branch}
                onChange={(e) =>
                  setStudentForm({ ...studentForm, branch: e.target.value })
                }
              >
                <option value="CSE">CSE</option>
                <option value="IT">IT</option>
                <option value="Mechanical">Mechanical</option>
                <option value="Civil">Civil</option>
              </select>
              <button className="btn btn-success w-100" onClick={addStudent}>
                Create Student
              </button>
            </div>
          </div>
        </div>
        <div className="col-md-6">
          <div className="card">
            <div className="card-header">Add Mentor</div>
            <div className="card-body">
              <input
                placeholder="Name"
                className="form-control mb-2"
                value={mentorForm.name}
                onChange={(e) =>
                  setMentorForm({ ...mentorForm, name: e.target.value })
                }
              />
              <input
                placeholder="Email"
                className="form-control mb-2"
                value={mentorForm.email}
                onChange={(e) =>
                  setMentorForm({ ...mentorForm, email: e.target.value })
                }
              />
              <button className="btn btn-info w-100" onClick={addMentor}>
                Create Mentor
              </button>
            </div>
          </div>
        </div>
      </div>
      <div className="row mt-4">
        <div className="col-md-6">
          <h5>Students</h5>
          <ul className="list-group">
            {users.students.map((s) => (
              <li key={s.id} className="list-group-item">
                {s.name} ({s.roll_number}) - {s.branch}
              </li>
            ))}
          </ul>
        </div>
        <div className="col-md-6">
          <h5>Mentors</h5>
          <ul className="list-group">
            {users.mentors.map((m) => (
              <li key={m.id} className="list-group-item">
                {m.name} ({m.email})
              </li>
            ))}
          </ul>
        </div>
      </div>
    </div>
  );
}
