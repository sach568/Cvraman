import { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import { createProject, getSubjects, getUsers } from "../api";

export default function CreateProject() {
  const [form, setForm] = useState({
    title: "",
    description: "",
    branch: "CSE",
    subject_id: "",
    mentor_id: "",
  });
  const [file, setFile] = useState(null);
  const [subjects, setSubjects] = useState([]);
  const [mentors, setMentors] = useState([]);
  const [error, setError] = useState("");
  const navigate = useNavigate();

  useEffect(() => {
    getSubjects().then((res) => setSubjects(res.data));
    getUsers().then((res) => setMentors(res.data.mentors));
  }, []);

  const handleSubmit = async (e) => {
    e.preventDefault();
    const fd = new FormData();
    Object.keys(form).forEach((k) => fd.append(k, form[k]));
    if (file) fd.append("file", file);
    try {
      await createProject(fd);
      navigate("/projects");
    } catch (err) {
      setError(
        "Failed to create project. Check file type (JPEG/PDF) and size.",
      );
    }
  };

  return (
    <div className="card shadow-sm">
      <div className="card-header bg-primary text-white">
        <i className="fas fa-plus-circle"></i> Create New Project
      </div>
      <div className="card-body">
        {error && <div className="alert alert-danger">{error}</div>}
        <form onSubmit={handleSubmit} encType="multipart/form-data">
          <div className="mb-3">
            <label className="form-label">Project Title *</label>
            <input
              type="text"
              className="form-control"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              required
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Description *</label>
            <textarea
              className="form-control"
              rows="4"
              value={form.description}
              onChange={(e) =>
                setForm({ ...form, description: e.target.value })
              }
              required
            />
          </div>
          <div className="mb-3">
            <label className="form-label">Branch *</label>
            <select
              className="form-select"
              value={form.branch}
              onChange={(e) => setForm({ ...form, branch: e.target.value })}
            >
              <option value="CSE">CSE</option>
              <option value="IT">IT</option>
              <option value="Mechanical">Mechanical</option>
              <option value="Civil">Civil</option>
            </select>
          </div>
          <div className="mb-3">
            <label className="form-label">Subject *</label>
            <select
              className="form-select"
              value={form.subject_id}
              onChange={(e) => setForm({ ...form, subject_id: e.target.value })}
              required
            >
              <option value="">Select Subject</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
          <div className="mb-3">
            <label className="form-label">Assign Mentor *</label>
            <select
              className="form-select"
              value={form.mentor_id}
              onChange={(e) => setForm({ ...form, mentor_id: e.target.value })}
              required
            >
              <option value="">Select Mentor</option>
              {mentors.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>
          <div className="mb-3">
            <label className="form-label">
              Upload File (JPEG/PDF, max 2MB)
            </label>
            <input
              type="file"
              className="form-control"
              accept=".jpeg,.jpg,.pdf"
              onChange={(e) => setFile(e.target.files[0])}
            />
          </div>
          <button type="submit" className="btn btn-primary">
            <i className="fas fa-save"></i> Create Project
          </button>
        </form>
      </div>
    </div>
  );
}
