import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { register } from "../api";

export default function Register({ setUser }) {
  const [form, setForm] = useState({
    name: "",
    email: "",
    roll_number: "",
    branch: "CSE",
    password: "",
    password_confirmation: "",
  });
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      const res = await register(form);
      if (res.data.success) {
        setUser(res.data.user);
        navigate("/dashboard");
      } else {
        setError(res.data.error || "Registration failed");
      }
    } catch (err) {
      setError("Registration failed. Please try again.");
    }
  };

  return (
    <div className="container mt-5">
      <div className="row justify-content-center">
        <div className="col-md-6">
          <div className="card shadow-sm border-0">
            <div className="card-header bg-success text-white text-center py-3">
              <h4>
                <i className="fas fa-user-plus"></i> Student Registration
              </h4>
            </div>
            <div className="card-body p-4">
              {error && <div className="alert alert-danger">{error}</div>}
              <form onSubmit={handleSubmit}>
                <div className="mb-3">
                  <label>Full Name</label>
                  <input
                    type="text"
                    className="form-control"
                    value={form.name}
                    onChange={(e) => setForm({ ...form, name: e.target.value })}
                    required
                  />
                </div>
                <div className="mb-3">
                  <label>Email</label>
                  <input
                    type="email"
                    className="form-control"
                    value={form.email}
                    onChange={(e) =>
                      setForm({ ...form, email: e.target.value })
                    }
                    required
                  />
                </div>
                <div className="mb-3">
                  <label>Roll Number</label>
                  <input
                    type="text"
                    className="form-control"
                    value={form.roll_number}
                    onChange={(e) =>
                      setForm({ ...form, roll_number: e.target.value })
                    }
                    required
                  />
                </div>
                <div className="mb-3">
                  <label>Branch</label>
                  <select
                    className="form-select"
                    value={form.branch}
                    onChange={(e) =>
                      setForm({ ...form, branch: e.target.value })
                    }
                  >
                    <option value="CSE">CSE</option>
                    <option value="IT">IT</option>
                    <option value="Mechanical">Mechanical</option>
                    <option value="Civil">Civil</option>
                  </select>
                </div>
                <div className="mb-3">
                  <label>Password</label>
                  <input
                    type="password"
                    className="form-control"
                    value={form.password}
                    onChange={(e) =>
                      setForm({ ...form, password: e.target.value })
                    }
                    required
                  />
                </div>
                <div className="mb-3">
                  <label>Confirm Password</label>
                  <input
                    type="password"
                    className="form-control"
                    value={form.password_confirmation}
                    onChange={(e) =>
                      setForm({
                        ...form,
                        password_confirmation: e.target.value,
                      })
                    }
                    required
                  />
                </div>
                <button type="submit" className="btn btn-success w-100">
                  <i className="fas fa-check-circle"></i> Register
                </button>
              </form>
              <div className="text-center mt-3">
                <a href="/login">Already have an account? Login</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
