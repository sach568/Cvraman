import { useState, useEffect } from "react";
import { getSubjects, addSubject, deleteSubject } from "../api";

export default function AdminSubjects() {
  const [subjects, setSubjects] = useState([]);
  const [newName, setNewName] = useState("");
  useEffect(() => {
    load();
  }, []);
  const load = async () => {
    const res = await getSubjects();
    setSubjects(res.data);
  };
  const handleAdd = async () => {
    await addSubject(newName);
    setNewName("");
    load();
  };
  const handleDelete = async (id) => {
    if (confirm("Delete?")) {
      await deleteSubject(id);
      load();
    }
  };
  return (
    <div>
      <h2>Manage Subjects</h2>
      <div className="input-group mb-3">
        <input
          type="text"
          className="form-control"
          value={newName}
          onChange={(e) => setNewName(e.target.value)}
          placeholder="New Subject"
        />
        <button className="btn btn-primary" onClick={handleAdd}>
          Add
        </button>
      </div>
      <ul className="list-group">
        {subjects.map((s) => (
          <li
            key={s.id}
            className="list-group-item d-flex justify-content-between"
          >
            <span>{s.name}</span>
            <button
              className="btn btn-sm btn-danger"
              onClick={() => handleDelete(s.id)}
            >
              Delete
            </button>
          </li>
        ))}
      </ul>
    </div>
  );
}
