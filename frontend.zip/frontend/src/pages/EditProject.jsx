import { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { getProject, updateProject, getSubjects, getUsers } from "../api";

export default function EditProject() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    title: "",
    description: "",
    branch: "CSE",
    subject_id: "",
    mentor_id: "",
  });
  const [subjects, setSubjects] = useState([]);
  const [mentors, setMentors] = useState([]);
  useEffect(() => {
    getProject(id).then((res) => setForm(res.data));
    getSubjects().then((res) => setSubjects(res.data));
    getUsers().then((res) => setMentors(res.data.mentors));
  }, [id]);
  const handleSubmit = async (e) => {
    e.preventDefault();
    await updateProject(id, form);
    navigate("/projects");
  };
  return (
    <div className="card">
      <div className="card-header">Edit Project</div>
      <div className="card-body">
        <form onSubmit={handleSubmit}>
          <div className="mb-3">
            <label>Title</label>
            <input
              type="text"
              className="form-control"
              value={form.title}
              onChange={(e) => setForm({ ...form, title: e.target.value })}
              required
            />
          </div>
          <div className="mb-3">
            <label>Description</label>
            <textarea
              className="form-control"
              rows="4"
              value={form.description}
              onChange={(e) =>
                setForm({ ...form, description: e.target.value })
              }
              required
            />
          </div>
          <div className="mb-3">
            <label>Branch</label>
            <select
              className="form-select"
              value={form.branch}
              onChange={(e) => setForm({ ...form, branch: e.target.value })}
            >
              <option value="CSE">CSE</option>
              <option value="IT">IT</option>
              <option value="Mechanical">Mechanical</option>
              <option value="Civil">Civil</option>
            </select>
          </div>
          <div className="mb-3">
            <label>Subject</label>
            <select
              className="form-select"
              value={form.subject_id}
              onChange={(e) => setForm({ ...form, subject_id: e.target.value })}
              required
            >
              <option value="">Select</option>
              {subjects.map((s) => (
                <option key={s.id} value={s.id}>
                  {s.name}
                </option>
              ))}
            </select>
          </div>
          <div className="mb-3">
            <label>Mentor</label>
            <select
              className="form-select"
              value={form.mentor_id}
              onChange={(e) => setForm({ ...form, mentor_id: e.target.value })}
              required
            >
              <option value="">Select</option>
              {mentors.map((m) => (
                <option key={m.id} value={m.id}>
                  {m.name}
                </option>
              ))}
            </select>
          </div>
          <button className="btn btn-primary">Update</button>
        </form>
      </div>
    </div>
  );
}
